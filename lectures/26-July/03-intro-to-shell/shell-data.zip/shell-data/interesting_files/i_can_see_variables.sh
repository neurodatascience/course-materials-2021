#!/bin/bash

# Print a message for two variables that could be passed in the environment
echo I can see this environment variable: ${ENV_VAR}. Very good
echo I cannot see this shell variable: ${shell_var}. How strange
